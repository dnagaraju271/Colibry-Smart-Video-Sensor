# Deduplicated 71 + 111 outdoor person-count scene dataset

Source collections: 71 legacy processed images + 111 additional timestamped images = 182 source entries.
Retained: 111 pixel-unique images after exact duplicate removal.
Removed: 71 legacy entries that exactly duplicate retained newer frames.

The old 71-image collection contributes no unique pixels: its 71 frames collapse to only three distinct 160x120 grayscale pixel patterns, and every one of these patterns is already present in the newer 111-image collection. The newer frames are retained to preserve their timestamped walking-scene sequences. See `duplicates_removed.csv` and `source_reconciliation.csv`.

## Image format and classes

- Resolution: 160 x 120 pixels
- Format: 8-bit grayscale PNG (mode L)
- Total retained images: 111
- Class folders: `0_person`, `1_person`, `2_person`, `3_person`, `4_person`

- 0_person: 1
- 1_person: 13
- 2_person: 58
- 3_person: 25
- 4_person: 14

The four-person class is included. The 0-person image is preserved as a separate folder; it is not a 1-4 people class.

## Filename convention

`I{count}_{scene}_{frame}.png`

Example: `2_person/I2_001_003.png` means two people, scene 001, frame 003.
The frame number increments across **all class folders** within the same scene, not separately inside each folder. Therefore one scene can contain e.g. `I1_001_001`, `I2_001_002`, `I2_001_003`, `I3_001_004`, and so on. Each frame is stored in its own person-count folder.

Scene groups follow the original WhatsApp timestamp. Inside each group, filename collision suffixes are ordered numerically: the unsuffixed base file, then `(1)`, `(2)`, etc. This yields a reproducible frame order, but does not establish exact sub-second capture chronology. Scenes retain their actual number of frames; no artificial images are added to make every scene exactly eight frames.

## Entry and exit direction

`scene_directions.csv` provides `entry_side`, `exit_side`, and `movement_direction` per scene; these values are also copied to every frame in `manifest.csv`.

Six longer reviewed sequences (15.08.18 through 15.08.23) are marked `LEFT_AND_RIGHT` for entry and exit, with `BIDIRECTIONAL` movement because people cross in both directions in those sequences. Shorter scenes do not prove a trackable path and are marked `UNKNOWN` instead of guessing. These are scene-level annotations only, not person tracks: the dataset has no persistent person IDs, boxes, or per-person trajectories.

## Files

- `manifest.csv`: source file, count, scene/frame ID, output path, direction, resolution, and pixel/file hashes.
- `scene_directions.csv`: scene-level entry/exit and direction annotations.
- `scene_summary.csv`: number of frames and class counts in each scene.
- `duplicates_removed.csv`: all 71 legacy frames mapped to their retained exact-pixel match.
- `source_reconciliation.csv`: source and retained counts.

ZIP integrity and all image dimensions/modes are verified.
