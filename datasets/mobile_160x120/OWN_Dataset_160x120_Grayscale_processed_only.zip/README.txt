OWN Dataset — current selected batch

Folders:
- 1_person: one visible person
- 2_person: two visible people
- 3_person: three visible people

Output: PNG, 160 pixels wide x 120 pixels high, 8-bit single-channel grayscale.
Aspect ratio is preserved; each image is fitted and centered on a neutral-gray
(127) canvas. Five sideways camera frames were rotated to landscape orientation.

Zero-person photos are not converted; their original JPEGs are in
pending_for_later_originals/ for your later instructions. No photos with more
than three people were identified. manifest.csv maps each reviewed source image
to its output. Original ZIP remains unchanged.
